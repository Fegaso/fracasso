const { sequelize, Sequelize } = require('../config/database');
const empregados = require('../models/empregados');
const empregadosModel = require("../models/empregados")(sequelize,Sequelize)

exports.showAll = (req,res)=> {

    empregadosModel.findAll(
        {
          order:[['nome','ASC']]
    }
    ).then(results=> {
        console.log(results);
        res.render('showAllView',{ layout:false, results_form:results })
    }).catch(err => {
        res.status(500).send({message: "Error" + err.message})
    })



}

exports.maiorSalario = async(req,res)=> {
     x=await empregadosModel.max('salarioBruto')
     console.log("X:",x)

    empregadosModel.findAll(
        {
          where: 
            {salarioBruto:x}
          
          
    }
    ).then(results=> {
        //console.log(results)

        res.render('showAllView',{ layout:false, results_form:results })
    }).catch(err => {
        res.status(500).send({message: "Error" + err.message})
    })



}



exports.adicionarEmpregado = (req,res) =>
{
    const empregado = {
        nome:req.body.nome,
        salarioBruto:req.body.salarioBruto,
        departamento:req.body.departamento
    };

    empregadosModel.create(empregado).then(data=> {
        console.log("Empregado adicionado");
        res.redirect('/showall');
    }).catch(err => {
        console.log("Error" + err);
    })

}

exports.showForm = (req,res) =>{
    res.render("form",{layout:false})
}

exports.delete = (req,res) => {
    const id_param = req.params.id;
    empregadosModel.destroy({
        where: {id:id_param}


    }).then((result)=>{
        if(!result){
            req.status(400).json(
                {message:"An error occurred..."}
            );
        }
        res.redirect("/showall");
    }).catch((err)=> {
        res.status(500).json({message:"Could not delete such object."});
        console.log(err);
    }
)
   
}

exports.editForm = (req,res) =>{

    const id_param = req.params.id;
    empregadosModel.findByPk(id_param).then(result => {
        res.render("editform",
            {
             layout:false, 
             id:id_param,
             results_data:result 
            }
        ) // render
    }

).catch(err => {
    res.status(500).json({message:"Error... Je suis désolé..."});
    console.log(err);
})//catch
   
}// editForm

exports.update = (req,res) => {

    empregadosModel.update(
    {
        nome:req.body.nome,
        salarioBruto: req.body.salarioBruto,
        departamento: req.body.departamento
    },{
        where: {id: req.body.id_for_updating}
    }
   ).then(anything=>{
       if(!anything){
        req.status(400).send({message:"An error ocurred."})
       }
       res.redirect('/showall');
   }).catch(err=>{
    res.status(500).send({
        message: "Error when trying to access the database"
    })
   })

}// update